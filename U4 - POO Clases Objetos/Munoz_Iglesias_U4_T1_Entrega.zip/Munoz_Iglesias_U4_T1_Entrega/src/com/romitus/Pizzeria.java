package com.romitus;

public class Pizzeria {
}

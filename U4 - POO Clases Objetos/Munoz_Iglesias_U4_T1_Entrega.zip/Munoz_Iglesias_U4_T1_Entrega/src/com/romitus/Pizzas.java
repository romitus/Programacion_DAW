package com.romitus;

/**
 * Clase Pizzas
 * Clase que determina el comportamiento de las pizzas.
 * @author Carlos Munoz
 * @version 0.1, 2020/01/17
 */

public class Pizzas {


    public enum Size{MEDIANA, FAMILIAR};
    private Ingredientes ingredientes[] = new Ingredientes[3];
    private Size size;
    private int numIngredientes;

    /**
     *  Este constructor crea un objeto Pizza donde se le pasa 2 valores por parametro.
     * @param size Tamaño de la pizza.
     * @param ingredientes Ingredientes que tiene la pizza.
     */

    public Pizzas(Size size, Ingredientes[] ingredientes) {
        this.size = size;
        this.ingredientes = ingredientes;
    }

    /**
     *  Este constructor crea un objeto Pizza donde se le pasa un valor por parametro.
     * @param ingredientes Ingredientes que tiene la pizza.
     */

    public Pizzas(Ingredientes[] ingredientes) {
        this.size = Size.FAMILIAR;
        this.ingredientes = ingredientes;
    }

    /**
     * Este constructor crea un objeto Pizza por defecto que tienen por parametro familiar con jamon y queso.
     */

    public Pizzas(){
        this.size = Size.FAMILIAR;
        Ingredientes i1 = new Ingredientes("Jamon",150);
        Ingredientes i3 = new Ingredientes();
        this.ingredientes[0] = i1;
        this.ingredientes[1] = i3;
        this.numIngredientes = 2;

    }

    /**
     * Este metodo muestra todos los tamaós de pizzas existentes.
     */

    public static void mostrarSize(){
        System.out.println("Tamaños de la pizza:");
        System.out.println(Size.FAMILIAR);
        System.out.println(Size.MEDIANA);
    }

    /**
     * Este metodo muestra toda la informacion de Pizza.
     */

    public void mostrarInformacion(){
        System.out.println(size);
        for (int i = 0; i < ingredientes.length; i++) {
            if (ingredientes[i] != null) {
                System.out.println(ingredientes[i].mostrarIngrediente());
            }
        }
    }
}
